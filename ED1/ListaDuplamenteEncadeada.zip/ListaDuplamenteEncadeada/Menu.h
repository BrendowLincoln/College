#include <iostream>
#include <stdio.h>
#include <stdlib.h>

int menu();

void clearTerminal(int os);